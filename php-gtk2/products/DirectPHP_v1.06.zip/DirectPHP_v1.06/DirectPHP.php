<?php
/**
* DirectPHP plugin
* allows direct embedding of PHP commands
* right inside Joomla content page for dynamic contents
* Author: kksou
* Copyright (C) 2006-2008. kksou.com. All Rights Reserved
* Website: http://www.kksou.com/php-gtk2
* v1.0 March 26, 2008
* v1.0.3 May 12, 2008
* v1.0.4 June 21, 2008
* v1.0.6 Apr, 2009 added using_no_editor in parameter
*/

defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );
$_MAMBOTS->registerFunction( 'onPrepareContent', 'botDirectPHP' );

function botDirectPHP( $published, &$row, &$params, $page=0  ) {

	if ( !$published ) {
		return true;
	}

	$plugin = new DirectPHP($row, "<?php", "?>");

	return true;
}

class DirectPHP {

	function DirectPHP(&$row, $php_start, $php_end) {

		$contents = $row->text;
		$contents = $this->fix_str($contents);
		global $database, $_MAMBOTS, $enable_command_block, $block_list;

		if ( !isset($_MAMBOTS->_content_mambot_params['DirectPHP']) ) {
			$query = "SELECT params"
			. "\n FROM #__mambots"
			. "\n WHERE element = 'DirectPHP'"
			. "\n AND folder = 'content'"
			;
			$database->setQuery( $query );
			$database->loadObject($mambot);
			$_MAMBOTS->_content_mambot_params['DirectPHP'] = $mambot;
		}

		$mambot = $_MAMBOTS->_content_mambot_params['DirectPHP'];
		$botParams = new mosParameters( $mambot->params );
		$using_no_editor = $botParams->def( 'using_no_editor', 0 );
		$enable_command_block = $botParams->def( 'enable_command_block', 1 );
		$block_list = $botParams->def( 'block_list', 'basename, chgrp, chmod, chown, clearstatcache, copy, delete, dirname, disk_free_space, disk_total_space, diskfreespace, fclose, feof, fflush, fgetc, fgetcsv, fgets, fgetss, file_exists, file_get_contents, file_put_contents, file, fileatime, filectime, filegroup, fileinode, filemtime, fileowner, fileperms, filesize, filetype, flock, fnmatch, fopen, fpassthru, fputcsv, fputs, fread, fscanf, fseek, fstat, ftell, ftruncate, fwrite, glob, lchgrp, lchown, link, linkinfo, lstat, move_uploaded_file, opendir, parse_ini_file, pathinfo, pclose, popen, readfile, readdir, readllink, realpath, rename, rewind, rmdir, set_file_buffer, stat, symlink, tempnam, tmpfile, touch, umask, unlink, fsockopen, system, exec, passthru, escapeshellcmd, pcntl_exec, proc_open, proc_close, mkdir, rmdir, mysql_connect, mysql_query, mysql_db_query, mysql_close, mysql_create_db, mysql_drop_db, mysql_info, mysql_get_server_info, mysql_get_host_info, mysql_list_dbs, mysql_list_processes, mysql_list_tables, mysql_pconnect, mysql_result, mysql_select_db, mysql_tablename, mysql_unbuffered_query' );
		$block_list = preg_replace('/\s*/s', '', $block_list);
		$block_list = explode(',', $block_list);

		$output = "";
		$regexp = '/(.*?)'.$this->fix_reg($php_start).'\s+(.*?)'.$this->fix_reg($php_end).'(.*)/s';
		$found = preg_match($regexp, $contents, $matches);
		while ($found) {
			$output .= $matches[1];
			$phpcode = $matches[2];
			#$phpcode2 = $this->fix_str2($phpcode);
			global $errmsg;
			if ($this->check_php($phpcode)) {
				ob_start();
				if ($using_no_editor) {
					eval($phpcode);
				} else {
					eval($this->fix_str2($phpcode));
				}
				$output .= ob_get_contents();
				ob_end_clean();
			} else {
				$output .= "The following command is not allowed: <b>$errmsg</b>";
			}
			$contents = $matches[3];
			$found = preg_match($regexp, $contents, $matches);
		}
		$output .= $contents;
		$row->text = $output;
	}

	function fix_str($str) {
		$str = preg_replace(array('%&lt;\?php(\s|&nbsp;|<br\s/>|<br>|<p>|</p>)%s', '/\?&gt;/s', '/-&gt;/'), array('<?php ', '?>', '->'), $str);
		return $str;
	}

	function fix_str2($str) {
		$str = str_replace('<br>', "\n", $str);
		$str = str_replace('<br />', "\n", $str);
		$str = str_replace('<p>', "\n", $str);
		$str = str_replace('</p>', "\n", $str);
		$str = str_replace('&#39;', "'", $str);
		$str = str_replace('&quot;', '"', $str);
		$str = str_replace('&lt;', '<', $str);
		$str = str_replace('&gt;', '>', $str);
		$str = str_replace('&amp;', '&', $str);
		$str = str_replace('&nbsp;', ' ', $str);
		$str = str_replace('&#160;', "\t", $str);
		$str = str_replace(chr(hexdec('C2')).chr(hexdec('A0')), '', $str);
		$str = str_replace(html_entity_decode("&Acirc;&nbsp;"), '', $str);
		return $str;
	}

	function fix_reg($str) {
		$str = str_replace('?', '\?', $str);
		$str = str_replace('{', '\{', $str);
		$str = str_replace('}', '\}', $str);
		return $str;
	}

	function check_php($code) {
		global $enable_command_block, $block_list, $errmsg;
		$status = 1;
		if (!$enable_command_block) return $status;
		$function_list = array();
		if (preg_match_all('/([a-zA-Z0-9_]+)\s*[(|"|\']/s', $code, $matches)) {
			$function_list = $matches[1];
		}

		if (preg_match('/`(.*?)`/s', $code)) {
			$status = 0;
			$errmsg = 'backticks (``)';
			return $status;
		}
		if (preg_match('/\$database\s*->\s*([a-zA-Z0-9_]+)\s*[(|"|\']/s', $code, $matches)) {
			$status = 0;
			$errmsg = 'database->'.$matches[1];
			return $status;
		}
		foreach($function_list as $command) {
			if (in_array($command, $block_list)) {
				$status = 0;
				$errmsg = $command;
				break;
			}
		}
		return $status;
	}

}

?>
