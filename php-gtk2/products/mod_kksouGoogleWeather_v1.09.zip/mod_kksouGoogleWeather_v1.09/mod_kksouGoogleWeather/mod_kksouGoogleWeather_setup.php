<?php
define( '_VALID_MOS', 1 );
require("joomla_root.php");
if (!function_exists('checkInputArray')) {
	require_once( "$joomla_root/globals.php" );
}
require("joomla_root.php");
require_once( "$joomla_root/configuration.php" );
require_once( "$joomla_root/includes/joomla.php" );
?>
