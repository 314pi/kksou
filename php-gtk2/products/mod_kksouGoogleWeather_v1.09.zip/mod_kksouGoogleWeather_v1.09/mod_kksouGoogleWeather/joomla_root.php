<?php
/**
* joomla_root.php
* Copyright (C) 2006-2009. kksou.com. All Rights Reserved
* License: GNU/GPL http://www.gnu.org/copyleft/gpl.html
* Website: http://www.kksou.com/php-gtk2
* v1.0 October 1, 2009
* 2012.10.26
*/

$fullpath = $_SERVER['DOCUMENT_ROOT'].$_SERVER['SCRIPT_NAME'];

$str = '';
$z = $fullpath;
$i = 0;
$ok = 0;
while (1) {
	$z2 = pathinfo($z);
	$str = $z2['basename'];
	++$i;
	if ($i>10) break;
	if ($str=='modules' || $str=='index.php') {
		$ok = 1;
		break;
	}
	$z = $z2['dirname'];
}
$joomla_root = $z2['dirname'];


/*****************************************************************
if the above doesn't work, please uncomment the following line and
input the full path of your joomla root folder here
*****************************************************************/

#$joomla_root = '/home/user/fullpath/to/your/joomla_root_folder';
?>
