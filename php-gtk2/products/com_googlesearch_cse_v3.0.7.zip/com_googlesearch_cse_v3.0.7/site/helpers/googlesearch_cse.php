<?php

/**
 * @version     3.0.1
 * @package     com_googlesearch_cse
 * @copyright   Copyright (C) kksou.com. All Rights Reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      kksou <support@kksou.com> - http://www.kksou.com/php-gtk2/
 */
defined('_JEXEC') or die;

class Googlesearch_cseFrontendHelper {
    
}
