<?php

/**
 * @version     3.0.1
 * @package     com_googlesearch_cse
 * @copyright   Copyright (C) kksou.com. All Rights Reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      kksou <support@kksou.com> - http://www.kksou.com/php-gtk2/
 */
// No direct access
defined('_JEXEC') or die;


require_once("googlesearch.lib.php");

#print "bp101. this is GoogleSearch!<br>";
#print "now = ".date('Y-m-d H:i:s')."<br>";

$db = JFactory::getDBO();
#$db->setQuery("SELECT * FROM #__googlesearch_cse_conf LIMIT 1");
$db->setQuery("SELECT * FROM #__googlesearch_cse_conf WHERE state='1' ORDER BY ordering LIMIT 1");

$rows = $db->loadObjectList();
$r = $rows[0];

#print "<pre>"; print_r($r); print "</pre>";

$app = new googleSearch_DisplayForm($r, '', '3.0', 0, '', 1);
