<?php
/**
 * @version     3.0.1
 * @package     com_googlesearch_cse
 * @copyright   Copyright (C) kksou.com. All Rights Reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      kksou <support@kksou.com> - http://www.kksou.com/php-gtk2/
 */


// no direct access
defined('_JEXEC') or die;

// Access check.
if (!JFactory::getUser()->authorise('core.manage', 'com_googlesearch_cse')) 
{
	throw new Exception(JText::_('JERROR_ALERTNOAUTHOR'));
}

// Include dependancies
jimport('joomla.application.component.controller');

$controller	= JControllerLegacy::getInstance('Googlesearch_cse');
$controller->execute(JFactory::getApplication()->input->get('task'));
$controller->redirect();
