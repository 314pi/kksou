DROP TABLE IF EXISTS `#__googlesearch_cse_conf`;
