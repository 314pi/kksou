<?php
/**
 * @version     3.0.1
 * @package     com_googlesearch_cse
 * @copyright   Copyright (C) kksou.com. All Rights Reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      kksou <support@kksou.com> - http://www.kksou.com/php-gtk2/
 */

// No direct access
defined('_JEXEC') or die;

jimport('joomla.application.component.controllerform');

/**
 * Googlesearchv1ew controller class.
 */
class Googlesearch_cseControllerGooglesearchv1ew extends JControllerForm
{

    function __construct() {
        $this->view_list = 'config';
        parent::__construct();
    }

}