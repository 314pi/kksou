<?php

/**
 * @version     3.0.1
 * @package     com_googlesearch_cse
 * @copyright   Copyright (C) kksou.com. All Rights Reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      kksou <support@kksou.com> - http://www.kksou.com/php-gtk2/
 */
defined('_JEXEC') or die;

jimport('joomla.application.component.modellist');

/**
 * Methods supporting a list of Googlesearch_cse records.
 */
class Googlesearch_cseModelConfig extends JModelList {

    /**
     * Constructor.
     *
     * @param    array    An optional associative array of configuration settings.
     * @see        JController
     * @since    1.6
     */
    public function __construct($config = array()) {
        if (empty($config['filter_fields'])) {
            $config['filter_fields'] = array(
                                'id', 'a.id',
                'google_id', 'a.google_id',
				'searchenginename', 'a.searchenginename',
                'width', 'a.width',
                'width_searchfield', 'a.width_searchfield',
                'search_button_label', 'a.search_button_label',
				'site_language', 'a.site_language',
				'site_encoding', 'a.site_encoding',
				'country', 'a.country',
				'safesearch', 'a.safesearch',
				'display_last_search', 'a.display_last_search',
				'intitle', 'a.intitle',
				'google_logo_pos', 'a.google_logo_pos',
				'button_pos', 'a.button_pos',
				'ad_pos', 'a.ad_pos',
				'watermark_type', 'a.watermark_type',
				'watermark_color_on_blur', 'a.watermark_color_on_blur',
				'watermark_color_on_focus', 'a.watermark_color_on_focus',
				'watermark_bg_color_on_blur', 'a.watermark_bg_color_on_blur',
				'watermark_bg_color_on_focus', 'a.watermark_bg_color_on_focus',
				'watermark_str', 'a.watermark_str',
				'mod_width_searchfield', 'a.mod_width_searchfield',
				'display_searchform', 'a.display_searchform',
				'mod_display_last_search', 'a.mod_display_last_search',
				'mod_button_pos', 'a.mod_button_pos',
				'mod_watermark_type', 'a.mod_watermark_type',
				'mod_watermark_color_on_blur', 'a.mod_watermark_color_on_blur',
				'mod_watermark_color_on_focus', 'a.mod_watermark_color_on_focus',
				'mod_watermark_bg_color_on_blur', 'a.mod_watermark_bg_color_on_blur',
				'mod_watermark_bg_color_on_focus', 'a.mod_watermark_bg_color_on_focus',
				'mod_watermark_str', 'a.mod_watermark_str',
                'ordering', 'a.ordering',
                'state', 'a.state',
                'created_by', 'a.created_by',
				'use_https', 'a.use_https', // added 161214
                'open_link_in_same_window', 'a.open_link_in_same_window', // added 161214

            );
        }

        parent::__construct($config);
    }

    /**
     * Method to auto-populate the model state.
     *
     * Note. Calling getState in this method will result in recursion.
     */
    protected function populateState($ordering = null, $direction = null) {
        // Initialise variables.
        $app = JFactory::getApplication('administrator');

        // Load the filter state.
        $search = $app->getUserStateFromRequest($this->context . '.filter.search', 'filter_search');
        $this->setState('filter.search', $search);

        $published = $app->getUserStateFromRequest($this->context . '.filter.state', 'filter_published', '', 'string');
        $this->setState('filter.state', $published);



        // Load the parameters.
        $params = JComponentHelper::getParams('com_googlesearch_cse');
        $this->setState('params', $params);

        // List state information.
        parent::populateState('a.google_id', 'asc');
    }

    /**
     * Method to get a store id based on model configuration state.
     *
     * This is necessary because the model is used by the component and
     * different modules that might need different sets of data or different
     * ordering requirements.
     *
     * @param	string		$id	A prefix for the store id.
     * @return	string		A store id.
     * @since	1.6
     */
    protected function getStoreId($id = '') {
        // Compile the store id.
        $id.= ':' . $this->getState('filter.search');
        $id.= ':' . $this->getState('filter.state');

        return parent::getStoreId($id);
    }

    /**
     * Build an SQL query to load the list data.
     *
     * @return	JDatabaseQuery
     * @since	1.6
     */
    protected function getListQuery() {
        // Create a new query object.
        $db = $this->getDbo();
        $query = $db->getQuery(true);

        // Select the required fields from the table.
        $query->select(
                $this->getState(
                        'list.select', 'DISTINCT a.*'
                )
        );
        $query->from('`#__googlesearch_cse_conf` AS a');


		// Join over the users for the checked out user
		$query->select("uc.name AS editor");
		$query->join("LEFT", "#__users AS uc ON uc.id=a.checked_out");
		// Join over the user field 'created_by'
		$query->select('created_by.name AS created_by');
		$query->join('LEFT', '#__users AS created_by ON created_by.id = a.created_by');



		// Filter by published state
		$published = $this->getState('filter.state');
		if (is_numeric($published)) {
			$query->where('a.state = ' . (int) $published);
		} else if ($published === '') {
			$query->where('(a.state IN (0, 1))');
		}

        // Filter by search in title
        $search = $this->getState('filter.search');
        if (!empty($search)) {
            if (stripos($search, 'id:') === 0) {
                $query->where('a.id = ' . (int) substr($search, 3));
            } else {
                $search = $db->Quote('%' . $db->escape($search, true) . '%');
                $query->where('( a.google_id LIKE '.$search.' )');
            }
        }




        // Add the list ordering clause.
        $orderCol = $this->state->get('list.ordering');
        $orderDirn = $this->state->get('list.direction');
        if ($orderCol && $orderDirn) {
            $query->order($db->escape($orderCol . ' ' . $orderDirn));
        }

        return $query;
    }

    public function getItems() {
        $items = parent::getItems();

        return $items;
    }

}
