<?php

/**
 * @version     3.0.1
 * @package     com_googlesearch_cse
 * @copyright   Copyright (C) kksou.com. All Rights Reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      kksou <support@kksou.com> - http://www.kksou.com/php-gtk2/
 */
// No direct access
defined('_JEXEC') or die;

/**
 * Googlesearch_cse helper.
 */
class Googlesearch_cseHelper {

    /**
     * Configure the Linkbar.
     */
    public static function addSubmenu($vName = '') {
        		JHtmlSidebar::addEntry(
			JText::_('COM_GOOGLESEARCH_CSE_TITLE_CONFIG'),
			'index.php?option=com_googlesearch_cse&view=config',
			$vName == 'config'
		);

    }

    /**
     * Gets a list of the actions that can be performed.
     *
     * @return	JObject
     * @since	1.6
     */
    public static function getActions() {
        $user = JFactory::getUser();
        $result = new JObject;

        $assetName = 'com_googlesearch_cse';

        $actions = array(
            'core.admin', 'core.manage', 'core.create', 'core.edit', 'core.edit.own', 'core.edit.state', 'core.delete'
        );

        foreach ($actions as $action) {
            $result->set($action, $user->authorise($action, $assetName));
        }

        return $result;
    }


}
