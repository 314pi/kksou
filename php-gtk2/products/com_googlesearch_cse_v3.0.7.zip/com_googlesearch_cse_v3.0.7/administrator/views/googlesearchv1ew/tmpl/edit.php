<?php
/**
 * @version     3.0.1
 * @package     com_googlesearch_cse
 * @copyright   Copyright (C) kksou.com. All Rights Reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      kksou <support@kksou.com> - http://www.kksou.com/php-gtk2/
 */
// no direct access
defined('_JEXEC') or die;

JHtml::addIncludePath(JPATH_COMPONENT . '/helpers/html');
JHtml::_('behavior.tooltip');
JHtml::_('behavior.formvalidation');
JHtml::_('formbehavior.chosen', 'select');
JHtml::_('behavior.keepalive');

// Import CSS
$document = JFactory::getDocument();
$document->addStyleSheet('components/com_googlesearch_cse/assets/css/googlesearch_cse.css');
?>
<script type="text/javascript">
    js = jQuery.noConflict();
    js(document).ready(function() {

    });

    Joomla.submitbutton = function(task)
    {
        if (task == 'googlesearchv1ew.cancel') {
            Joomla.submitform(task, document.getElementById('googlesearchv1ew-form'));
        }
        else {

            if (task != 'googlesearchv1ew.cancel' && document.formvalidator.isValid(document.id('googlesearchv1ew-form'))) {

                Joomla.submitform(task, document.getElementById('googlesearchv1ew-form'));
            }
            else {
                alert('<?php echo $this->escape(JText::_('JGLOBAL_VALIDATION_FORM_FAILED')); ?>');
            }
        }
    }

	jQuery(document).ready(function () {
	    jQuery("#google_id_remarks").hide();

	    jQuery("#btn1").click(function(){
		 jQuery("#google_id_remarks").toggle();
	    });
	});
</script>

<form action="<?php echo JRoute::_('index.php?option=com_googlesearch_cse&layout=edit&id=' . (int) $this->item->id); ?>" method="post" enctype="multipart/form-data" name="adminForm" id="googlesearchv1ew-form" class="form-validate">

    <div class="form-horizontal">
        <?php echo JHtml::_('bootstrap.startTabSet', 'myTab', array('active' => 'general')); ?>

        <?php echo JHtml::_('bootstrap.addTab', 'myTab', 'general', JText::_('COM_GOOGLESEARCH_CSE_TITLE_GOOGLESEARCHV1EW', true)); ?>
        <div class="row-fluid">
            <div class="span10 form-horizontal">
                <fieldset class="adminform">

                    				<input type="hidden" name="jform[id]" value="<?php echo $this->item->id; ?>" />
			<div class="control-group">
				<div class="control-label"><?php echo $this->form->getLabel('google_id'); ?></div>
				<div class="controls"><?php echo $this->form->getInput('google_id'); ?> </div>
				<div id="btn1" class="button"><a href="#">Where to find the Google CSE ID...</a></div>
			</div>

			<div id="google_id_remarks">
<?php
$path = JPATH_COMPONENT.'/assets/js';
if (preg_match('/com_googlesearch_cse/', $path)) {
	$path = str_replace('administrator/components/', 'components/', $path);
	require_once("$path/msg.php");
	global $google_id_msg1, $google_id_msg2;
	print $google_id_msg2;
}
?>
			</div>

			<div class="control-group">
				<div class="control-label"><?php echo $this->form->getLabel('searchenginename'); ?></div>
				<div class="controls"><?php echo $this->form->getInput('searchenginename'); ?></div>
			</div>

			<div class="control-group">
				<div class="control-label"><?php echo $this->form->getLabel('width'); ?></div>
				<div class="controls"><?php echo $this->form->getInput('width'); ?></div>
			</div>

			<div class="control-group">
				<div class="control-label"><?php echo $this->form->getLabel('width_searchfield'); ?></div>
				<div class="controls"><?php echo $this->form->getInput('width_searchfield'); ?></div>
			</div>

			<div class="control-group">
				<div class="control-label"><?php echo $this->form->getLabel('search_button_label'); ?></div>
				<div class="controls"><?php echo $this->form->getInput('search_button_label'); ?></div>
			</div>

			<div class="control-group">
				<div class="control-label"><?php echo $this->form->getLabel('site_language'); ?></div>
				<div class="controls"><?php echo $this->form->getInput('site_language'); ?></div>
			</div>

			<div class="control-group">
				<div class="control-label"><?php echo $this->form->getLabel('site_encoding'); ?></div>
				<div class="controls"><?php echo $this->form->getInput('site_encoding'); ?></div>
			</div>

			<div class="control-group">
				<div class="control-label"><?php echo $this->form->getLabel('country'); ?></div>
				<div class="controls"><?php echo $this->form->getInput('country'); ?></div>
			</div>

			<div class="control-group">
				<div class="control-label"><?php echo $this->form->getLabel('safesearch'); ?></div>
				<div class="controls"><?php echo $this->form->getInput('safesearch'); ?></div>
			</div>

			<div class="control-group">
				<div class="control-label"><?php echo $this->form->getLabel('display_last_search'); ?></div>
				<div class="controls"><?php echo $this->form->getInput('display_last_search'); ?></div>
			</div>

<?php
/*
			<div class="control-group">
				<div class="control-label"><?php echo $this->form->getLabel('intitle'); ?></div>
				<div class="controls"><?php echo $this->form->getInput('intitle'); ?></div>
			</div>
*/
?>

<?php
	#$path = JPATH_COMPONENT.'/assets/gif';
	$path = JURI::base().'components/com_googlesearch_cse/assets/gif';
	print "<p></p><div>";
	print "<table border=4>";
	for ($i=0; $i<3; ++$i) {
		$j = $i+1;
		print "<tr valign=\"top\"><td>Google logo $j</td><td><img src=\"$path/google_cse{$i}.gif\" border=\"0\" alt=\"google_cse0.gif\" /></tr>";
	}
	print "</table>";
	print "</div><p></p>";

?>

			<div class="control-group">
				<div class="control-label"><?php echo $this->form->getLabel('google_logo_pos'); ?></div>
				<div class="controls"><?php echo $this->form->getInput('google_logo_pos'); ?></div>
			</div>

			<div class="control-group">
				<div class="control-label"><?php echo $this->form->getLabel('button_pos'); ?></div>
				<div class="controls"><?php echo $this->form->getInput('button_pos'); ?></div>
			</div>

			<div class="control-group">
				<div class="control-label"><?php echo $this->form->getLabel('open_link_in_same_window'); ?></div>
				<div class="controls"><?php echo $this->form->getInput('open_link_in_same_window'); ?></div>
			</div>

			<div class="control-group">
				<div class="control-label"><?php echo $this->form->getLabel('use_https'); ?></div>
				<div class="controls"><?php echo $this->form->getInput('use_https'); ?></div>
			</div>

<?php
/*

			<div class="control-group">
				<div class="control-label"><?php echo $this->form->getLabel('ad_pos'); ?></div>
				<div class="controls"><?php echo $this->form->getInput('ad_pos'); ?></div>
			</div>

			<div class="control-group">
				<div class="control-label"><?php echo $this->form->getLabel('watermark_type'); ?></div>
				<div class="controls"><?php echo $this->form->getInput('watermark_type'); ?></div>
			</div>

			<div class="control-group">
				<div class="control-label"><?php echo $this->form->getLabel('watermark_color_on_blur'); ?></div>
				<div class="controls"><?php echo $this->form->getInput('watermark_color_on_blur'); ?></div>
			</div>

			<div class="control-group">
				<div class="control-label"><?php echo $this->form->getLabel('watermark_color_on_focus'); ?></div>
				<div class="controls"><?php echo $this->form->getInput('watermark_color_on_focus'); ?></div>
			</div>

			<div class="control-group">
				<div class="control-label"><?php echo $this->form->getLabel('watermark_bg_color_on_blur'); ?></div>
				<div class="controls"><?php echo $this->form->getInput('watermark_bg_color_on_blur'); ?></div>
			</div>

			<div class="control-group">
				<div class="control-label"><?php echo $this->form->getLabel('watermark_bg_color_on_focus'); ?></div>
				<div class="controls"><?php echo $this->form->getInput('watermark_bg_color_on_focus'); ?></div>
			</div>

			<div class="control-group">
				<div class="control-label"><?php echo $this->form->getLabel('watermark_str'); ?></div>
				<div class="controls"><?php echo $this->form->getInput('watermark_str'); ?></div>
			</div>
*/
?>

			<div><p></p>
			<b>Note: </b>The following settings are for use with the <a href="http://www.kksou.com/php-gtk2/Joomla-Gadgets/googleSearch-CSE-module.php"><b>googleSearch_cse module</b></a> to be used in conjunction with this component. If you're not using the googleSearch_cse module, you can ignore the following settings.
			<p></p>
			</div>

			<div class="control-group">
				<div class="control-label"><?php echo $this->form->getLabel('mod_width_searchfield'); ?></div>
				<div class="controls"><?php echo $this->form->getInput('mod_width_searchfield'); ?></div>
			</div>


			<div class="control-group">
				<div class="control-label"><?php echo $this->form->getLabel('display_searchform'); ?></div>
				<div class="controls"><?php echo $this->form->getInput('display_searchform'); ?></div>
			</div>


			<div class="control-group">
				<div class="control-label"><?php echo $this->form->getLabel('mod_display_last_search'); ?></div>
				<div class="controls"><?php echo $this->form->getInput('mod_display_last_search'); ?></div>
			</div>

			<div class="control-group">
				<div class="control-label"><?php echo $this->form->getLabel('mod_button_pos'); ?></div>
				<div class="controls"><?php echo $this->form->getInput('mod_button_pos'); ?></div>
			</div>

<?php
/*
			<div class="control-group">
				<div class="control-label"><?php echo $this->form->getLabel('mod_watermark_type'); ?></div>
				<div class="controls"><?php echo $this->form->getInput('mod_watermark_type'); ?></div>
			</div>

			<div class="control-group">
				<div class="control-label"><?php echo $this->form->getLabel('mod_watermark_color_on_blur'); ?></div>
				<div class="controls"><?php echo $this->form->getInput('mod_watermark_color_on_blur'); ?></div>
			</div>

			<div class="control-group">
				<div class="control-label"><?php echo $this->form->getLabel('mod_watermark_color_on_focus'); ?></div>
				<div class="controls"><?php echo $this->form->getInput('mod_watermark_color_on_focus'); ?></div>
			</div>

			<div class="control-group">
				<div class="control-label"><?php echo $this->form->getLabel('mod_watermark_bg_color_on_blur'); ?></div>
				<div class="controls"><?php echo $this->form->getInput('mod_watermark_bg_color_on_blur'); ?></div>
			</div>

			<div class="control-group">
				<div class="control-label"><?php echo $this->form->getLabel('mod_watermark_bg_color_on_focus'); ?></div>
				<div class="controls"><?php echo $this->form->getInput('mod_watermark_bg_color_on_focus'); ?></div>
			</div>

			<div class="control-group">
				<div class="control-label"><?php echo $this->form->getLabel('mod_watermark_str'); ?></div>
				<div class="controls"><?php echo $this->form->getInput('mod_watermark_str'); ?></div>
			</div>
*/
?>

				<input type="hidden" name="jform[ordering]" value="<?php echo $this->item->ordering; ?>" />
				<input type="hidden" name="jform[state]" value="<?php echo $this->item->state; ?>" />
				<input type="hidden" name="jform[checked_out]" value="<?php echo $this->item->checked_out; ?>" />
				<input type="hidden" name="jform[checked_out_time]" value="<?php echo $this->item->checked_out_time; ?>" />

				<?php if(empty($this->item->created_by)){ ?>
					<input type="hidden" name="jform[created_by]" value="<?php echo JFactory::getUser()->id; ?>" />

				<?php }
				else{ ?>
					<input type="hidden" name="jform[created_by]" value="<?php echo $this->item->created_by; ?>" />

				<?php } ?>

                </fieldset>
            </div>
        </div>
        <?php echo JHtml::_('bootstrap.endTab'); ?>



        <?php echo JHtml::_('bootstrap.endTabSet'); ?>

        <input type="hidden" name="task" value="" />
        <?php echo JHtml::_('form.token'); ?>

    </div>
</form>