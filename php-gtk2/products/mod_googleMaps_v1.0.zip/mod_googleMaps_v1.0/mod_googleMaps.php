<?php
/**
* googleMaps module
* This module allows you to display one or more google maps
* in a module position
* Make sure you have the googleMaps plugin installed
* Author: kksou
* Copyright (C) 2006-2008. kksou.com. All Rights Reserved
* Website: http://www.kksou.com/php-gtk2
* v1.0 April 16, 2009
*/

defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

@session_start();
$str = $params->get( 'content', '' );
$str = str_replace('~', '<br />', $str);
$str = str_replace('[p]', '</p>', $str);
$str = str_replace('[/p]', '</p>', $str);

$a = new stdClass;
$a->text = $str;
global $_MAMBOTS;
$_MAMBOTS->loadBotGroup( 'content' );
#$params = array();
$params = new stdClass;
$params->is_mod = 1;
#$results = $_MAMBOTS->trigger( 'onPrepareContent', array( 1, &$a, &$params) );
$results = $_MAMBOTS->trigger( 'onPrepareContent', array( 1, $a, $params) );
echo $a->text;
?>
