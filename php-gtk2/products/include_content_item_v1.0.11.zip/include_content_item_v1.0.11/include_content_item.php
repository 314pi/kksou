<?php
/**
* include_content_item plugin
* This plugin allows you to insert or include one content item
* into another content item.
* Author: kksou
* Copyright (C) 2006-2008. kksou.com. All Rights Reserved
* License: GNU/GPL http://www.gnu.org/copyleft/gpl.html
* Website: http://www.kksou.com/php-gtk2
* v1.0 May 3, 2008
*/

defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );
$_MAMBOTS->registerFunction( 'onPrepareContent', 'botIncludeContentItem' );
$lib = dirname(__FILE__).'/include_content_item/include_content_item.lib.php';
require_once($lib);

function botIncludeContentItem( $published, &$row, &$params, $page=0  ) {
	if ( !$published ) {
		#$row->text = preg_replace( $regex, '', $row->text );
		return true;
	}
	$plugin = new Plugin_IncludeContentItem($row, '1.0');
	return true;
}

?>
