<?php
$joomla_ver = '3.0';
?>
