<?php
/**
* Pausing up-down Scroller module
* This module allows you to display an up-down scroller that pauses
* between each message! The look of the scroller is completely styled
* using external CSS, including the dimensions. Easily create a single
* line scroller just by adjusting the scroller's height appropriately!
* Author: kksou
* Copyright (C) 2006-2008. kksou.com. All Rights Reserved
* Website: http://www.kksou.com/php-gtk2/Joomla-Gadgets/
* v1.5 December 3, 2008
*/

// no direct access
defined('_JEXEC') or die('Restricted access');

$moduleclass_sfx = $params->get('moduleclass_sfx');
$a = new stdClass;
#$dispatcher	=& JDispatcher::getInstance();
$dispatcher	= JDispatcher::getInstance();
JPluginHelper::importPlugin('content');
$a->text = $str;
$a->params = array();
#$results = $dispatcher->trigger('onPrepareContent', array (&$a, &$a->params, 0));
$results = $dispatcher->trigger('onContentPrepare', array ('mod.com_content.article', &$a, &$a->params, 0));
echo $a->text;
?>