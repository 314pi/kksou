<?php
/**
* Pausing up-down Scroller module
* This module allows you to display an up-down scroller that pauses
* between each message! The look of the scroller is completely styled
* using external CSS, including the dimensions. Easily create a single
* line scroller just by adjusting the scroller's height appropriately!
* Author: kksou
* Copyright (C) 2006-2008. kksou.com. All Rights Reserved
* Website: http://www.kksou.com/php-gtk2/Joomla-Gadgets/
* v1.5 December 3, 2008
* v1.72 December 4, 2011 support for Joomla 1.6 and 1.7
*/

// no direct access
defined('_JEXEC') or die('Restricted access');
require_once (dirname(__FILE__).DS.'helper.php');
$str = modpausing_up_down_scrollerHelper::getContent($params);
require(JModuleHelper::getLayoutPath('mod_pausing_up_down_scroller'));
?>