<?php
/**
* googleSearch component
* This component allows you to add Google Adsense Search to your Joomla site
* with the search results displayed right inside your Joomla page!
* @version 1.0
* @package None
* @copyright (C) Copyright 2006-2009 by kksou.com
* Author: kksou
* Website: http://www.kksou.com/php-gtk2
* v1.0 Jan 3, 2009
*/

defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

require_once( $mosConfig_absolute_path .'/components/com_googlesearch_cse/googlesearch.lib.php' );

global $database;
$database->setQuery("SELECT * FROM #__googleSearch_cse_conf LIMIT 1");
$rows = $database->loadObjectList();
$r = $rows[0];

$app = new googleSearch_DisplayForm($r, '', '1.0', 0, '', 1);
?>