googleSearch_cse v1.0 for Joomla 1.5.x
This component allows you to add Google's new Custom Search Engine (CSE) to your Joomla site with the search results displayed right inside your Joomla page!
================================================================================
Author:    kksou
Email:     support@kksou.com
Published: January 3, 2009
Version:   1.0
Website:   http://www.kksou.com/php-gtk2/Joomla/googleSearch-component.php
Copyright (C) 2006-2009. kksou.com. All Rights Reserved. 

================================================================================
LICENSE

This program is released under the GNU/GPL License - http://www.gnu.org/copyleft/gpl.html

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

================================================================================
DISCLAIMER

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
