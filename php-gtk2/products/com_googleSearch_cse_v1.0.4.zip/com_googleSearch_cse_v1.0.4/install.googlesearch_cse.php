<?php
function com_install() {
}
?> 
