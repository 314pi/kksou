<?php
defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

require_once( $mosConfig_absolute_path .'/administrator/components/com_googlesearch_cse/admin.googlesearch.lib.php' );

class HTML_googleSearch{
	function listConfiguration($option, &$rows) {
		$app = new googleSearch_config($option, $rows[0], '1.0', 1);
	}
}

?>