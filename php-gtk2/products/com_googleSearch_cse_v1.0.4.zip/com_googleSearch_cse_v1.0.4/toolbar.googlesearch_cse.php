<?php
defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );
require_once( $mainframe->getPath( 'toolbar_html' ) );

#switch($act) {
#	case "configure":
		menu_googleSearch::CONFIGURE_MENU();
#		break;
#}

?>
