<?php
defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

class menu_googleSearch{
	function CONFIGURE_MENU() {
		mosMenuBar::startTable();
		mosMenuBar::save('save');
		mosMenuBar::endTable();
	}
}

?>