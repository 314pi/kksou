<?php
defined('_VALID_MOS') or die('Direct Access to this location is not allowed.');

// ensure user has access to this function
if (!($acl->acl_check( 'administration', 'edit', 'users', $my->usertype, 'components', 'all' )
		| $acl->acl_check( 'administration', 'edit', 'users', $my->usertype, 'components', 'com_googleSearch_cse' ))) {
	mosRedirect( 'index2.php', _NOT_AUTH );
}

require_once( $mainframe->getPath( 'admin_html' ) );
require_once( $mainframe->getPath( 'class' ) );

$id = mosGetParam( $_REQUEST, 'cid', array(0) );
if (!is_array( $id )) {
	$id = array(0);
}

switch($act) {
	case "configure":
	switch($task) {
		case "save":
			saveConfiguration($option);
			break;

		default:
			listConfiguration($option);
			break;
	}
	break;
}


function saveConfiguration($option) {
	global $database;

	$row = new googleSearch_cse_conf($database);

	#if (trim($_POST['google_id'])=='') {
	#	echo "<script> alert('Please enter your google adsense ID.'); window.history.go(-1); </script>\n";
	#	exit();
	#}

	/* if (trim($_POST['google_id'])!='' && !preg_match('/^\d{16}$/', $_POST['google_id'])) {
		echo "<script> alert('The google adsense ID should be a 16-digit number.'); window.history.go(-1); </script>\n";
		exit();
	} */

	if (trim($_POST['width'])=='' || $_POST['width']<=0) {
		echo "<script> alert('Please enter the width of the search result in pixels.'); window.history.go(-1); </script>\n";
		exit();
	}

	if ($_POST['width_searchfield']<=0) $_POST['width_searchfield']=32;
	if ($_POST['width_searchfield_module']<=0) $_POST['width_searchfield_module']=16;

	if (!preg_match('/^\d+$/', $_POST['width'])) {
		echo "<script> alert('The width of the search result should be a number in pixels.'); window.history.go(-1); </script>\n";
		exit();
	}

	if (preg_match('/^---/', $_POST['site_encoding'])) $_POST['site_encoding'] = 'ISO-8859-1';

	// check colors
	/*
	googleSearch_check_color('title_color');
	googleSearch_check_color('bg_color');
	googleSearch_check_color('text_color');
	googleSearch_check_color('url_color');
	*/

	// bind it to the table
	if (!$row -> bind($_POST)) {
		echo "<script> alert('"
			.$row -> getError()
			."'); window.history.go(-1); </script>\n";
		exit();
	}

	// store it in the db
	if (!$row -> store()) {
		echo "<script> alert('"
			.$row -> getError()
			."'); window.history.go(-1); </script>\n";
		exit();
	}

	mosRedirect("index2.php?option=$option&act=configure", "Configuration Saved");
}


function listConfiguration($option) {
	global $database;

	$database->setQuery("SELECT * FROM #__googleSearch_cse_conf"  );
	$rows = $database -> loadObjectList();
	if ($database -> getErrorNum()) {
		echo $database -> stderr();
		return false;
	}
	HTML_googleSearch::listConfiguration($option, $rows);
}

function googleSearch_check_color($fieldname) {
	$label = str_replace('_', ' ', $fieldname);
	$regexp = '/^[0-9a-fA-F]{6}$/';
	if (preg_match($regexp, $_POST[$fieldname])) $_POST[$fieldname] = '#'.$_POST[$fieldname];
	$regexp = '/^#[0-9a-fA-F]{6}$/';
	$_POST[$fieldname] = strtoupper($_POST[$fieldname]);
	if (!preg_match($regexp, $_POST[$fieldname])) {
		echo "<script> alert('You have entered \'{$_POST[$fieldname]}\' for $label. Please enter the color in hexadecimal format e.g. #3366FF'); window.history.go(-1); </script>\n";
		exit();
	}
}

?>
