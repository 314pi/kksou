<?php
/**
* kksouWeather module
* This module allows you to add the Google Weather in a module position.
* Author: kksou
* Copyright (C) 2006-2009. kksou.com. All Rights Reserved
* License: GNU/GPL http://www.gnu.org/copyleft/gpl.html
* Website: http://www.kksou.com/php-gtk2
* v1.5 October 1, 2009
* v1.51 October 6, 2009 Streamlined the javascript codes
* v1.52 Jan 20, 2010
* - allow user to define the popup prompt in their own language
* - added support for IE8
* - no longer shows San Francisco in the input field when you have defined other city as default
* v1.53 Feb 14 added a flag to allow user to choose whether to put the focus on the input field for city
* v1.54 May 06, 2010 Conforms to joomla.org guidelines.
* v1.55 May 16, 2010 Conforms to W3C XHTML 1.0 Transitional
* v1.6.6 Oct 10, 2011 support for Joomla 1.6 and PHP 5.3.8
* v1.7.6 Oct 10, 2011 support for Joomla 1.7 and PHP 5.3.8
* v1.7.7 Oct 17, 2011 support for km/h
* v2.5.8 Aug 28, 2012 google weather API no longer working. switched to using wunderground.com
* v2.5.9 Sep 8, 2012 used cookies to remember user's last entered city
*                    on server side - retrieve weather information once every hour
* v3.0.10 19 Apr, 2013 Support for Joomla 3.0
*                      Support for different $dbprefix
*                      Support for $use_mysql_direct
*                      Added debug mode
*/

/* wunderground.com allows 500 per day
Every 6 min 2 calls - one current, one forecast. 6 min = 6 * 60 = 360 sec
Every hour => 20 calls
Every 24 hours => 480 calls */

global $use_mysql_direct;
global $debug_mode;
require_once("mod_kksouWeather_mysql.php");
date_default_timezone_set('America/Los_Angeles');
if ($debug_mode) print "bp301. use_mysql_direct = $use_mysql_direct<br />";

if (!$use_mysql_direct) {
	if (isset($_GET['joomla_root'])) $joomla_root = $_GET['joomla_root'];
	$joomla_root = str_replace('|_%$', '/', $joomla_root);
	global $database;
	require_once("mod_kksouWeather_setup.php");
	if ($debug_mode) print "bp302. setup ok<br />";
}

require_once("mod_kksouWeather_libclass.php");
if ($debug_mode) print "bp303. libclassp ok<br />";

#if(session_id() == '') {
@session_start();
#}

if (isset($_GET['request_interval'])) $request_interval = $_GET['request_interval'];
if (!isset($_SESSION['googleWeather_timestart'])) $_SESSION['googleWeather_timestart'] = microtime(1);
$timestart = $_SESSION['googleWeather_timestart'];
$elapsed_time = microtime(1)-$timestart;
if ($elapsed_time<$request_interval) {
	$diff = intval($request_interval - $elapsed_time);
	sleep($diff);
}
$_SESSION['googleWeather_timestart'] = microtime(1);

$data = '';
if (isset($_GET['mod_id'])) $mod_id = $_GET['mod_id'];
if (isset($_GET['googleweather_unit'])) $googleweather_unit = $_GET['googleweather_unit'];
if (isset($_GET['api_key'])) $api_key = $_GET['api_key'];
if (isset($_GET['toF']) && $_GET['toF']==1) $googleweather_unit = 'US';
if (isset($_GET['toC']) && $_GET['toC']==1) $googleweather_unit = 'SI';

if (isset($_GET['hide_humidity'])) $hide_humidity = $_GET['hide_humidity'];
if (isset($_GET['hide_wind'])) $hide_wind = $_GET['hide_wind'];
if (isset($_GET['hide_forecast'])) $hide_forecast = $_GET['hide_forecast'];
if (isset($_GET['label_humidity'])) $label_humidity = $_GET['label_humidity'];
if (isset($_GET['default_country'])) $default_country = $_GET['default_country'];
if (isset($_GET['joomla_ver'])) $joomla_ver = $_GET['joomla_ver'];
if (isset($_GET['refresh_time'])) $refresh_time = $_GET['refresh_time'];
if (isset($_GET['admin_mode'])) $admin_mode = $_GET['admin_mode'];
if ($debug_mode) $admin_mode = 1;

global $gw_data;
$gw_data = '';

if (isset($_GET['process'])) {

	#$str_a = 'San Francisco';
	$str_a = '';
	if (isset($_GET['gw_a']) && $_GET['gw_a']!='') $str_a = $_GET['gw_a'];
	if (isset($_GET['lang'])) $lang = $_GET['lang'];
	$hl = '';
	#if ($lang!='') $hl = "&hl=$lang";
	if ($lang!='') $hl = "/lang:".strtoupper($lang);
	if (trim($str_a)!='') {
		#$url = "http://www.google.com/ig/api?weather=".urlencode($str_a).$hl;
		#$url = "http://api.wunderground.com/api/$api_key/geolookup/conditions/q/Singapore/Singapore.json";
		#$url2 = "http://api.wunderground.com/api/$api_key/geolookup/forecast/q/Singapore/Singapore.json";
		$ok = 0;
		if (preg_match('/(.*),(.*)/', $str_a, $matches)) {
			$city = trim(ltrim($matches[1]));
			$country = trim(ltrim($matches[2]));
			$ok = 1;
		} else {
			if ($default_country!='') {
				$city = trim(ltrim($str_a));
				$country = $default_country;
				$ok = 1;
			} else {
				$data = '<span class="error">For USA, please specify City, State<br />For other countries, please specify City, Country</span>';
			}
		}
		if ($ok) {
			$city = str_replace(' ', '_', $city);
			$country = str_replace(' ', '_', $country);
			$gw_app = new GoogleWeather();
			$gw_app->get_weather($city, $country, $api_key, $hl);
			$data = $gw_data;
		}

	}
}


$str_a = '';
if (isset($_GET['gw_a'])) $str_a = $_GET['gw_a'];
#if ($str_a=='') $str_a = 'San Francisco';
$popup_city = '';
if (isset($_GET['label_city'])) $label_city = $_GET['label_city'];
if (isset($_GET['size_city'])) $size_city = $_GET['size_city'];
if (isset($_GET['hide_input'])) $hide_input = $_GET['hide_input'];
if (isset($_GET['popup_city'])) $popup_city = $_GET['popup_city'];

$z = "<a href=\"http://www.kksou.com/php-gtk2/Joomla-Gadgets/Google-Weather-AJAX-version.php\" style=\"color:#aaa;text-decoration: none;font-family:Tahoma, Arial, Helvetica, sans-serif;font-size:7pt;font-weight: normal;\">Powered by JoomlaGadgets</a>";
$z1 = "<p align=\"left\" style=\"padding:0 0 0 0;margin:0 0 0 0\">$z</p>";

print "<form action=\"index.php\" method=\"get\" id=\"WeatherForm{$mod_id}\">";
#print "<form action=\"index.php\" method=\"get\" id=\"WeatherForm{$mod_id}\" onsubmit=\"javascript:gw_submitform('$mod_id');return false;\">";
print "<div class=\"googleWeather\">";

if (!$hide_input) {
	print "<span class=\"input_label\">$label_city: </span>";
	print "<input name=\"gw_a\" id=\"str_gw_a{$mod_id}\" class=\"inputbox\" maxlength=\"255\" size=\"$size_city\" value=\"$str_a\" title=\"$popup_city\" />&nbsp;";
	#print "<span id=\"gw_loading{$mod_id}\" align=\"left\"></span><br />";
	print "<span id=\"gw_loading{$mod_id}\"></span><br />";
}
if ($data!='') print $data;
if ($hide_input) {
	print "<input type=\"hidden\" name=\"gw_a\" id=\"str_gw_a{$mod_id}\" class=\"inputbox\" value=\"$str_a\" />";
	#print "<span id=\"gw_loading{$mod_id}\" align=\"left\"></span>";
	print "<span id=\"gw_loading{$mod_id}\"></span>";
}
print "<input type=\"hidden\" name=\"a_org\" id=\"str_gw_a_org{$mod_id}\" class=\"inputbox\" value=\"$str_a\" />";

print "<div align=\"left\" style=\"padding-top:2px;\">$z1</div>";

print "<input type=\"hidden\" name=\"process\" value=\"1\" />";
print "<input type=\"hidden\" name=\"temp_unit\" id=\"temp_unit{$mod_id}\" value=\"$googleweather_unit\" />";

$option = '';
if (isset($_REQUEST['option'])) $option = $_REQUEST['option'];
print "<input type=\"hidden\" name=\"option\" value=\"$option\" />";

$task = '';
if (isset($_REQUEST['task'])) $task = $_REQUEST['task'];
print "<input type=\"hidden\" name=\"task\" value=\"$task\" />";

$id = '';
if (isset($_REQUEST['id'])) $id = $_REQUEST['id'];
print "<input type=\"hidden\" name=\"id\" value=\"$id\" />";

$sectionid = '';
if (isset($_REQUEST['sectionid'])) $sectionid = $_REQUEST['sectionid'];
print "<input type=\"hidden\" name=\"sectionid\" value=\"$sectionid\" />";

$catid = '';
if (isset($_REQUEST['catid'])) $catid = $_REQUEST['catid'];
print "<input type=\"hidden\" name=\"catid\" value=\"$catid\" />";

$Itemid = '';
if (isset($_REQUEST['Itemid'])) $Itemid = $_REQUEST['Itemid'];
print "<input type=\"hidden\" name=\"Itemid\" value=\"$Itemid\" />";
print '</div>';
print '</form>';

?>
