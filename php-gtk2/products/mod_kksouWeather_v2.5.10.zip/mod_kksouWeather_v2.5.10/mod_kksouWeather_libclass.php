<?php
/**
* kksouWeather module
* This module allows you to add the Google Weather in a module position.
* Author: kksou
* Copyright (C) 2006-2009. kksou.com. All Rights Reserved
* License: GNU/GPL http://www.gnu.org/copyleft/gpl.html
* Website: http://www.kksou.com/php-gtk2
* v1.5 October 1, 2009
*/

class GoogleWeather_base {

	var $html = '';
	var $data = '';

	function process() {
		global $googleweather_unit;
		global $hide_humidity, $hide_wind, $hide_forecast, $label_humidity, $default_country;
		$data = '';

		if ($this->html=='overlimit') {
			$data = $this->html2;
			return $data;
		}

		if ($this->html=='need_to_wait') {
			$data = $this->html2;
			return $data;
		}

		if ($this->html=='' || $this->html2=='') {
			$data = '<span class="error">There was no response from the weather server.</span>';
			return $data;
		}

		$parsed_json = @json_decode($this->html);
		$parsed_json2 = @json_decode($this->html2);

		if (isset($parsed_json->response->error)) {
			#print "bp421.<pre>"; print_r($parsed_json->response->error); print "</pre>";
			$str = $parsed_json->response->error->type;
			$desc = $parsed_json->response->error->description;
			if ($str == 'keynotfound') {
				$data = '<span class="error">Error: API Key not found</span><br />Please obtain the free Developer API Key from <a href="http://www.wunderground.com/weather/api/?apiref=6eae7a10209d1cc0">www.wunderground.com</a>';
			} else {
				$data = "<span class=\"error\">Error: $str</span> ($desc)";
			}
			return $data;
		}

		if (isset($parsed_json->response->results)) {
			$items = $parsed_json->{'response'}->{'results'};
			$data = '<span class="error">Multiple Cities: </span>';
			$i = 0;
			foreach($items as $item) {
				++$i;
				if ($item->country=='US') {
					$data .= "<br />$i. ".$item->city.', '.$item->state.' (US)';
				} else {
					$data .= "<br />$i. ".$item->city.', '.$item->country_name;
				}
			}
			return $data;
		}

		if (isset($parsed_json2->response->error)) {
			#print "bp421.<pre>"; print_r($parsed_json2->response->error); print "</pre>";
			$str = $parsed_json2->response->error->type;
			$desc = $parsed_json2->response->error->description;
			if ($str == 'keynotfound') {
				$data = '<span class="error">Error: API Key not found</span><br />Please obtain the free Developer API Key from <a href="http://www.wunderground.com/weather/api/?apiref=6eae7a10209d1cc0">www.wunderground.com</a>';
			} else {
				$data = "<span class=\"error\">Error: $str</span> ($desc)";
			}
			return $data;
		}

		$city = $parsed_json->{'location'}->{'city'};
		$state = $parsed_json->{'location'}->{'state'};
		$country = $parsed_json->{'location'}->{'country'};
		$country_name = $parsed_json->{'location'}->{'country_name'};
		if ($country=='US') $city2 = $city.', '.$state;
		else {
			$city2 = $city;
			if ($country_name!='') $city2 = $city.', '.$country_name;
		}

		$img1 = $parsed_json->{'current_observation'}->{'icon_url'};
		$data .= "<img class=\"img2\" src=\"$img1\">";
		$data .= "<span class=\"city\">$city2</span><br />";
		global $mod_id;
		$popup_deg_F = '';
		$popup_deg_C = '';
		if (isset($_GET['popup_deg_F'])) $popup_deg_F = $_GET['popup_deg_F'];
		if (isset($_GET['popup_deg_C'])) $popup_deg_C = $_GET['popup_deg_C'];
		if ($googleweather_unit=='SI') {
			#$data .= "<span class=\"deg\"><a href=\"javascript:gw_toF('$mod_id');\" title=\"Click here to convert to &deg;F\">{$current->temp_c['data']}&deg;C</a></span>&nbsp;&nbsp;";
			$temp_c = $parsed_json->{'current_observation'}->{'temp_c'};
			$data .= "<span class=\"deg\"><a href=\"javascript:gw_toF('$mod_id');\" title=\"$popup_deg_F\">$temp_c&deg;C</a></span>&nbsp;&nbsp;";
		} else {
			#$data .= "<span class=\"deg\"><a href=\"javascript:gw_toC('$mod_id');\" title=\"Click here to convert to &deg;C\">{$current->temp_f['data']}&deg;F</a></span>&nbsp;&nbsp;";
			$temp_f = $parsed_json->{'current_observation'}->{'temp_f'};
			$data .= "<span class=\"deg\"><a href=\"javascript:gw_toC('$mod_id');\" title=\"$popup_deg_C\">$temp_f&deg;F</a></span>&nbsp;&nbsp;";
		}
		$data .= "<span class=\"cond\">{$parsed_json->{'current_observation'}->{'weather'}}</span><br />";
		#if (!$hide_humidity) $data .= "<span class=\"humidity\">$label_humidity: {$parsed_json->{'current_observation'}->{'relative_humidity'}}</span><br />";
		$label_humidity2 = $label_humidity;
		if ($label_humidity2!='') $label_humidity2 .= ' ';
		if (!$hide_humidity) $data .= "<span class=\"humidity\">$label_humidity2{$parsed_json->{'current_observation'}->{'relative_humidity'}}</span><br />";
		#if (!$hide_humidity) $data .= "<span class=\"humidity\">{$parsed_json->{'current_observation'}->{'relative_humidity'}}</span><br />";
		#if (!$hide_wind) $data .= "<span class=\"wind\">{$current->wind_condition['data']}</span><br />";

		if (!$hide_wind) {
			$wind_dir = $parsed_json->{'current_observation'}->{'wind_dir'};
			if ($googleweather_unit=='SI') {
				$wind = $parsed_json->{'current_observation'}->{'wind_kph'}.' km/h';
			} else {
				$wind = $parsed_json->{'current_observation'}->{'wind_mph'}.' mph';
			}
			#$wind = $this->get_wind_speed($current->wind_condition['data'], $unit, $googleweather_unit);
			//$data .= "unit($unit) unit2($googleweather_unit)<br />";
			if ($wind!='') $data .= "<span class=\"wind\">$wind_dir: $wind</span><br />";
		}

		if (!$hide_forecast) {
			$data .= "<table border=0>";
			for ($i=0; $i<4; ++$i) {
				#$low = $this->get_temp($forecast[$i]->low['data'], $unit, $googleweather_unit);
				#$high = $this->get_temp($forecast[$i]->high['data'], $unit, $googleweather_unit);

				$str = $parsed_json2->{'forecast'}->{'simpleforecast'}->{'forecastday'};
				if ($googleweather_unit=='SI') {
					$low = $str[$i]->{'low'}->{'celsius'};
					$high = $str[$i]->{'high'}->{'celsius'};
				} else {
					$low = $str[$i]->{'low'}->{'fahrenheit'};
					$high = $str[$i]->{'high'}->{'fahrenheit'};
				}

				$data .= "<tr valign=top>";
				$data .= "<td class=\"forecast_day\">{$str[$i]->{'date'}->{'weekday_short'}}</td>";
				$data .= "<td  class=\"forecast_img\"><img img src=\"{$str[$i]->{'icon_url'}}\" width=\"20\" title=\"{$str[$i]->{'conditions'}}\"></td> ";
				$data .= "<td class=\"forecast_temp\">$low&nbsp;|&nbsp;$high</td>";
				$data .= "<td class=\"forecast_cond\">{$str[$i]->{'conditions'}}&nbsp;</td>";
				$data .= "</tr>";
			}
			$data .= "</table>";
		}

		return $data;
	}

	function process_google() {
		global $googleweather_unit;
		global $hide_humidity, $hide_wind, $hide_forecast;
		$data = '';

		$parsed_json = json_decode($this->html);
		print "<pre>"; print_r($parsed_json); print "</pre>";
		return;

		if (preg_match('%<H1>Bad\sRequest<\/H1>%i', $this->html)) {
			$data = '<span class="error">Google server did not respond. Please try again.</span>';
			return $data;
		}

		$xml = simplexml_load_string($this->html);

		if (isset($xml->weather->problem_cause))  {
			$data = '<span class="error">No such city or zip code.</span>';
			return $data;
		}

		$info = &$xml->weather->forecast_information;
		$current = &$xml->weather->current_conditions;
		$forecast = &$xml->weather->forecast_conditions;

		$city = $info->city['data'];
		$unit = $info->unit_system['data'];
		$city = strtoupper(substr($city,0,1)).substr($city,1);
		$data .= "<img class=\"img2\" src=\"http://www.google.com{$current->icon['data']}\">";
		$data .= "<span class=\"city\">$city</span><br />";
		global $mod_id;
		$popup_deg_F = '';
		$popup_deg_C = '';
		if (isset($_GET['popup_deg_F'])) $popup_deg_F = $_GET['popup_deg_F'];
		if (isset($_GET['popup_deg_C'])) $popup_deg_C = $_GET['popup_deg_C'];
		if ($googleweather_unit=='SI') {
			#$data .= "<span class=\"deg\"><a href=\"javascript:gw_toF('$mod_id');\" title=\"Click here to convert to &deg;F\">{$current->temp_c['data']}&deg;C</a></span>&nbsp;&nbsp;";
			$data .= "<span class=\"deg\"><a href=\"javascript:gw_toF('$mod_id');\" title=\"$popup_deg_F\">{$current->temp_c['data']}&deg;C</a></span>&nbsp;&nbsp;";
		} else {
			#$data .= "<span class=\"deg\"><a href=\"javascript:gw_toC('$mod_id');\" title=\"Click here to convert to &deg;C\">{$current->temp_f['data']}&deg;F</a></span>&nbsp;&nbsp;";
			$data .= "<span class=\"deg\"><a href=\"javascript:gw_toC('$mod_id');\" title=\"$popup_deg_C\">{$current->temp_f['data']}&deg;F</a></span>&nbsp;&nbsp;";
		}
		$data .= "<span class=\"cond\">{$current->condition ['data']}</span><br />";
		if (!$hide_humidity) $data .= "<span class=\"humidity\">{$current->humidity['data']}</span><br />";
		#if (!$hide_wind) $data .= "<span class=\"wind\">{$current->wind_condition['data']}</span><br />";

		if (!$hide_wind) {
			$wind = $this->get_wind_speed($current->wind_condition['data'], $unit, $googleweather_unit);
			//$data .= "unit($unit) unit2($googleweather_unit)<br />";
			if ($wind!='') $data .= "<span class=\"wind\">$wind</span><br />";
		}

		if (!$hide_forecast) {
			$data .= "<table border=0>";
			for ($i=0; $i<4; ++$i) {
				$low = $this->get_temp($forecast[$i]->low['data'], $unit, $googleweather_unit);
				$high = $this->get_temp($forecast[$i]->high['data'], $unit, $googleweather_unit);
				$data .= "<tr valign=top>";
				$data .= "<td class=\"forecast_day\">{$forecast[$i]->day_of_week['data']}</td>";
				$data .= "<td  class=\"forecast_img\"><img img src=\"http://www.google.com{$forecast[$i]->icon['data']}\" width=\"20\" title=\"{$forecast[$i]->condition ['data']}\"></td> ";
				$data .= "<td class=\"forecast_temp\">$low&nbsp;|&nbsp;$high</td>";
				$data .= "<td class=\"forecast_cond\">{$forecast[$i]->condition ['data']}&nbsp;</td>";
				$data .= "</tr>";
			}
			$data .= "</table>";
		}

		return $data;
	}

	function get_temp($temp, $unit, $user_specified_unit) {
		if ($user_specified_unit=='SI') {
			if ($unit=='US') $temp = $this->to_C($temp);
		} elseif ($user_specified_unit=='US') {
			if ($unit=='SI')$temp = $this->to_F($temp);
		}
		return $temp;
	}

	function get_wind_speed($str_wind_speed, $unit, $user_specified_unit) {
		if (trim($str_wind_speed)=='') return '';
		$wind_speed = '';
		if ($user_specified_unit=='SI') {
			if ($unit=='US') {
				if (preg_match('/(.*)\s(\d+) mph$/', $str_wind_speed, $matches)) {
					$org_speed = $matches[2];
					$speed = $this->to_kmh($org_speed);
					$wind_speed = $matches[1].' '.$speed.' km/h';
				} else $wind_speed = $str_wind_speed;
			} else $wind_speed = $str_wind_speed;
		} elseif ($user_specified_unit=='US') {
			if ($unit=='SI'){
				if (preg_match('/(.*)\s(\d+) km\/h$/', $str_wind_speed, $matches)) {
					$org_speed = $matches[2];
					$speed = $this->to_mph($org_speed);
					$wind_speed = $matches[1].' '.$speed.' mph';
				} else $wind_speed = $str_wind_speed;
			} else $wind_speed = $str_wind_speed;
		}
		return $wind_speed;
	}

	function to_F($temp) {
	    return intval(($temp*9/5)+32);
	}

	function to_C($temp) {
	    return intval(($temp-32)*5/9);
	}

	function to_mph($speed) {
	    return intval($speed/1.6093);
	}

	function to_kmh($speed) {
	    return intval($speed * 1.6093);
	}

}

class GoogleWeather extends GoogleWeather_base {
	var $binary = 0;
	var $new = 0;

	# wunderground.com allows 500 per day
	# Each weather enquiry requires 2 requests (current + forecast)
	# 250 calls per 24 hrs
	# each hr can make 250/24 = 10.416 calls
	var $DAILY_LIMIT = 500;

	# get_weather v3
	# 2012.10.16
	function get_weather($city, $country, $api_key, $hl) {
		global $refresh_time;
		global $admin_mode;
		global $debug_mode;

		$this->setup_db();

		if ($this->no_cache) {

			if ($admin_mode) print "&gt; problem setting up cache - accessing weather server directly";
			$this->get_new_weather_data2($city, $country, $api_key, $hl);

		} else {

			# check if $city and $country already in table
			$city2 = $this->mysql_addslashes($city);
			$country2 = $this->mysql_addslashes($country);
			if (!$this->city_already_in_db($city, $country)) {
				#if ($admin_mode) print "&gt; city NOT FOUND: $city ($country)<br />";

				if ($admin_mode) print "&gt; city NOT FOUND in cache<br />";

				$this->get_new_weather_data($city, $country, $api_key, $hl);

			} else {
				
				if ($debug_mode) print "&gt; city = $city, $country<br />";
				if ($admin_mode) print "&gt; city found in cache<br />";

				$query = "SELECT weather1, weather2, timestamp2  FROM $this->db_name WHERE city='$city2' AND country='$country2'";
				$r = $this->db_query4($query);

				# if ($admin_mode) print "bp311. use cached data: $city ($country)<br />";

				$elapsed_time = $this->elapsed_time($r->timestamp2);
				if ($admin_mode) print "&gt; elapsed time = $elapsed_time min<br />";

				if ($elapsed_time > $refresh_time) {
					if ($admin_mode) print "&gt; more than $refresh_time min: refresh data<br />";
					$this->get_new_weather_data($city, $country, $api_key, $hl);
				} else {
					if ($admin_mode) print "&gt; within $refresh_time min: use cache<br />";
					$this->html = $r->weather1;
					$this->html2 = $r->weather2;
				}

			}
		}

		global $gw_data;
		$gw_data = $this->process();
	}

	# get_weather_org - original v1.58
	# 2012.10.16
	function get_weather_org($city, $country, $api_key, $hl) {
		$url = "http://api.wunderground.com/api/$api_key/geolookup/conditions{$hl}/q/$country/$city.json";
		$url2 = "http://api.wunderground.com/api/$api_key/geolookup/forecast{$hl}/q/$country/$city.json";
		$this->get_page($url, $url2);

		global $gw_data;
		$gw_data = $this->process();
	}

	# elapsed_time
	# 2012.10.16
	function elapsed_time($prev_time) {
		$elapsed_time2 = 0;
		$time_now = time();
		$elapsed_time = $time_now - $prev_time;
		$elapsed_time2 = round($elapsed_time/60, 2);
		return $elapsed_time2;
	}

	# reset_counter
	# 2012.10.19
	function reset_counter() {
		$prev_hr = $this->db_query3("SELECT hr FROM $this->db_name_count WHERE id2=25");
		$current_time = date('Y-m-d H:i:s');
		$current_hr = date('G');

		if ($current_hr != $prev_hr) {
			$query = "UPDATE $this->db_name_count set hr='$current_hr' WHERE id2=25";
			$this->db_query($query);

			$current_hr2 = $this->get_current_hr();
			$query = "UPDATE $this->db_name_count set n='0' WHERE id2=$current_hr2";
			$this->db_query($query);
		}

	}

	# get_current_hr
	# 2012.10.21
	function get_current_hr() {
		$current_time = date('Y-m-d H:i:s');
		$current_hr = date('G');
		$current_hr2 = $current_hr;
		if ($current_hr2==0) $current_hr2 = 24;
		return $current_hr2;
	}

	# increment_counter
	# 2012.10.21
	function increment_counter() {
		$current_hr = $this->get_current_hr();
		$val = $this->db_query3("SELECT n FROM $this->db_name_count WHERE id2=$current_hr");
		#print "bp352. val = $val<br />";
		++$val;
		$query = "UPDATE $this->db_name_count set n='$val' WHERE id2=$current_hr";
		$this->db_query($query);
	}

	# get_new_weather_data
	# 2012.10.16
	function get_new_weather_data($city, $country, $api_key, $hl) {
		global $admin_mode;
		$this->reset_counter();
		$total_count = $this->db_query3("SELECT SUM(n) as total_count FROM $this->db_name_count");
		$total_count2 = $total_count * 2;
		if ($admin_mode) print "&gt; number of calls = $total_count2<br />";

		$daily_limit = $this->DAILY_LIMIT / 2;
		if ($total_count > $daily_limit) {
			if ($admin_mode) print "&gt; OVER LIMIT: $this->DAILY_LIMIT<br />";
			$this->html = 'overlimit';
			$this->html2 = "<span class=\"error\">You have reached the daily limit of 500 calls per day set by wunderground.com.</span>";
		} else {
			if ($admin_mode) print "&gt; retrieve fresh data from server<br />";
			$this->get_new_weather_data2($city, $country, $api_key, $hl);
		}
	}

	# get_new_weather_data2
	# 2012.10.16
	function get_new_weather_data2($city, $country, $api_key, $hl) {
		$url = "http://api.wunderground.com/api/$api_key/geolookup/conditions{$hl}/q/$country/$city.json";
		$url2 = "http://api.wunderground.com/api/$api_key/geolookup/forecast{$hl}/q/$country/$city.json";
		$this->get_page($url, $url2);

		# make sure there's no error before making a copy of weather info
		if ($this->html=='' || $this->html2=='') {
			#print "bp212.1 null result<br />";
		} else {
			$parsed_json = @json_decode($this->html);
			$parsed_json2 = @json_decode($this->html2);
			if (isset($parsed_json->response->error)) {
				#print "bp212.2 error1<br />";
			} elseif (isset($parsed_json->response->results)) {
				#print "bp212.3 error2<br />";
			} elseif (isset($parsed_json2->response->error)) {
				#print "bp212.4 error3<br />";
			} elseif (isset($parsed_json2->response->results)) {
				#print "bp212.3 error2<br />";
			} else {

				# check if $city and $country already in table
				$city2 = $this->mysql_addslashes($city);
				$country2 = $this->mysql_addslashes($country);
				if (!$this->city_already_in_db($city, $country)) {
					$query = "INSERT INTO $this->db_name (city, country, weather1, weather2, timestamp2) VALUES ('$city2', '$country2', '$this->html', '$this->html2', unix_timestamp())";
					$this->db_query($query);
				} else {
					$query = "UPDATE $this->db_name SET weather1='$this->html', weather2='$this->html2', timestamp2=unix_timestamp() WHERE city='$city2' AND country='$country2'";
					$this->db_query($query);
				}

				#$this->update_record1_time();
				$this->increment_counter();
			}
		}
	}

	# city_already_in_db
	# 2012.10.16
	function city_already_in_db($city, $country) {
		$city2 = $this->mysql_addslashes($city);
		$country2 = $this->mysql_addslashes($country);
		$query = "SELECT * FROM $this->db_name WHERE city='$city2' AND country='$country2'";
		$num_rows = $this->db_query2($query);
		if ($num_rows>0) $found = 1;
		else $found = 0;
		return $found;
	}


	# setup_db
	# 2012.10.16
	function setup_db() {
		global $admin_mode;
		global $joomla_ver;
		global $dbprefix;
		global $debug_mode;
		
		global $use_mysql_direct;
		if ($use_mysql_direct) {			
			$this->db_name = $dbprefix.'kksouWeather';
			$this->db_name_count = $this->db_name.'_count';
		} else {
			if ($joomla_ver=='1.0') {
				global $database;
				$this->database = $database;
				$dbprefix = 'jos_';
			} else {
				$this->database = JFactory::getDBO();
				$dbprefix = $this->database->getPrefix();
			}
			$this->db_name = $dbprefix.'kksouWeather';
			$this->db_name_count = $this->db_name.'_count';
		}
		if ($debug_mode) print "bp311. db_name = $this->db_name ($dbprefix)<br />";
		
		if ($this->new) {
			$this->db_query("DROP TABLE $this->db_name;");
			$this->db_query("DROP TABLE $this->db_name_count;");
		}

		# create table if necessary
		$query = "SHOW TABLES LIKE '$this->db_name'";
		$num_rows = $this->db_query2($query);
		if ($debug_mode) print "bp312. num_rows = $num_rows ($query)<br />";
		
		$this->no_cache = 0;

		if ($num_rows==0) {
			if ($this->create_db1()) {
				$query = "INSERT INTO $this->db_name (id, timestamp, timestamp2) VALUES ('1', '', 0)";
				#$query = "INSERT INTO $this->db_name (timestamp2) VALUES (unix_timestamp())";
				$result = $this->db_query($query);
				if (!$result && $admin_mode) print "&gt; error inserting record into cache file #1: ".$this->database->ErrorMsg()."<br />";
			} else {
				$this->no_cache = 1;
			}
		}

		$query = "SHOW TABLES LIKE '$this->db_name_count'";
		$num_rows = $this->db_query2($query);

		if ($num_rows==0) {
			if ($this->create_db2()) {
				for ($i=1; $i<=24; ++$i) {
					$query = "INSERT INTO $this->db_name_count (id2, hr, n) VALUES ('$i', '$i', '10')";
					$result = $this->db_query($query);
					if (!$result && $admin_mode) print "&gt; error inserting record 1-24 into cache file #2: ".$this->database->ErrorMsg()."<br />";
				}
				#$current_time = date('Y-m-d H:i:s');
				#$current_hr = date('G');
				$current_hr = -1;
				$query = "INSERT INTO $this->db_name_count (id2, hr, n) VALUES ('25', '$current_hr', '0')";
				$result = $this->db_query($query);
				if (!$result && $admin_mode) print "&gt; error inserting record 25 into cache file #2: ".$this->database->ErrorMsg()."<br />";

			} else {
				$this->no_cache = 1;
			}
		}
	}

	# create_db1
	# 2012.10.16
	function create_db1() {
		global $admin_mode;
		$query = "CREATE TABLE $this->db_name (
  `id` int(11) NOT NULL auto_increment,
  `city` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `weather1` text NOT NULL,
  `weather2` text NOT NULL,
  `timestamp` timestamp NOT NULL,
  `timestamp2` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
);";
		$ok = 1;
		$result = $this->db_query($query);
		if (!$result) {
			if ($admin_mode) {
				print "&gt; error creating cache file #1: ".$this->database->ErrorMsg()."<br />";
			} else {
				print "&gt; error creating cache file #1<br />";
			}
			$ok = 0;
		} else {
			if ($admin_mode) print "&gt; cache file #1 created<br />";
		}
		return $ok;
	}

	# create_db2
	# 2012.10.16
	function create_db2() {
		global $admin_mode;
		$query2 = "CREATE TABLE $this->db_name_count (
  `id2` int(11) NOT NULL auto_increment,
  `hr` int NOT NULL,
  `n` int NOT NULL,
  `timestamp` timestamp NOT NULL,
  PRIMARY KEY  (`id2`)
);";
		$ok = 1;
		$result = $this->db_query($query2);
		if (!$result) {
			if ($admin_mode) {
				print "&gt; error creating cache file #2: ".$this->database->ErrorMsg()."<br />";
			} else {
				print "&gt; error creating cache file #2<br />";
			}
			$ok = 0;
		} else {
			if ($admin_mode) print "&gt; cache file #2 created<br />";
		}
		return $ok;
	}

	# db_query
	function db_query($query) {
		global $use_mysql_direct;
		if ($use_mysql_direct) {
			$result = mysql_query($query);
		} else {		
			$this->database->setQuery( $query );
			$result = $this->database->query();
		}
		return $result;
	}

	# db_query2
	function db_query2($query) {
		global $admin_mode;
		global $use_mysql_direct;
		if ($use_mysql_direct) {
			$result = mysql_query($query);
			$num_rows = mysql_num_rows($result);
		} else {
			$this->database->setQuery( $query );
			$result = $this->database->query();
			if ($result==null) {
				print "&gt; DB_ERROR2: ".$this->database->ErrorMsg()."<br />";
				$num_rows = 0;
			} else {
				$num_rows = $this->database->getNumRows($result);
			}
		}
		return $num_rows;
	}

	# db_query3
	# 2012.10.21
	# This method loads the first field of the first row returned by the query.
	function db_query3($query) {
		global $admin_mode;
		global $use_mysql_direct;
		if ($use_mysql_direct) {
			$result = mysql_query($query);
			$val = '';
			if ($result==null) {
				$num_rows = 0;
				$val = null;
			} else {
				$num_rows = mysql_num_rows($result);
				if ($num_rows>0) {
					$row = mysql_fetch_array($result);
					$val = $row[0];
				}
			}
		} else {
			$this->database->setQuery( $query );
			$result = $this->database->query();
			$val = '';
			if ($result==null) {
				print "&gt; DB_ERROR3: ".$this->database->ErrorMsg()."<br />";
				$num_rows = 0;
				$val = null;
			} else {
				$num_rows = $this->database->getNumRows($result);
				if ($num_rows>0) {
					#$rows = $this->database->loadObjectList();
					#$r = $rows[0];
					#$rows = $this->database->loadResultArray();
					$val = $this->database->loadResult();
				}
			}
		}
		return $val;
	}

	# db_query4
	# 2012.10.21
	# This method loads the first field of the first row returned by the query.
	function db_query4($query) {
		global $admin_mode;
		global $use_mysql_direct;
		if ($use_mysql_direct) {
			$result = mysql_query($query);
			$val = '';
			if ($result==null) {
				$num_rows = 0;
				$val = null;
			} else {
				$num_rows = mysql_num_rows($result);
				if ($num_rows>0) {
					global $joomla_ver;
					$row = mysql_fetch_object($result);
				}
			}			
		} else {
			$this->database->setQuery( $query );
			$result = $this->database->query();
			$val = '';
			if ($result==null) {
				print "&gt; DB_ERROR4: ".$this->database->ErrorMsg()."<br />";
				$num_rows = 0;
				$val = null;
			} else {
				$num_rows = $this->database->getNumRows($result);
				if ($num_rows>0) {
					global $joomla_ver;
					if ($joomla_ver=='1.0') {
						$rows = $this->database->loadObjectList();
						$row = $rows[0];
					} else {
						$row = $this->database->loadObject();
					}
					#$rows = $this->database->loadObjectList();
					#$r = $rows[0];
					#$rows = $this->database->loadResultArray();
					#$val = $this->database->loadResult();
					#$rows = $this->database->loadAssoc(); // load first row as associative arrays
					#$rows = $this->database->loadAssocList(); // load all rows as associative arrays
					#$row = $this->database->loadRow(); // load first row into array
					#$rows = $this->database->loadRowList(); // load all rows into arrays
				}
			}
		}
		return $row;
	}

	function get_page($url, $url2) {
		if ($url!='') {
			/*$ch = curl_init ();
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($ch, CURLOPT_URL, $url);
			#curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
			#curl_setopt($ch, CURLOPT_BINARYTRANSFER, $this->binary);
			curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
			curl_setopt($ch, CURLOPT_TIMEOUT, 60);
			$this->html = curl_exec($ch);
			curl_close($ch);*/
			$this->html = file_get_contents($url);
		}
		if ($url2!='') {
			$this->html2 = file_get_contents($url2);
		}
	}

	/**************************************************************
	func0102 function mysql_addslashes($var)
	Description: add slashes in front of '
	arg1: the var
	2005.8.16 Yu Chen Kuang
	**************************************************************/
	function mysql_addslashes($var) {
		$t = get_magic_quotes_gpc ();
		if (! get_magic_quotes_gpc ()) {
			$z = str_replace("'", "''",$var);
			$z = str_replace("\\", "\\\\",$z);
		} else {
			$z = $var;
		}
		return $z;
	}
}

?>
