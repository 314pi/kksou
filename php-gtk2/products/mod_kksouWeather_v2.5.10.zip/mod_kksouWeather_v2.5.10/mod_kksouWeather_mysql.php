<?php
/**
* mod_kksouWeather_mysql.php
* Author: kksou
* Copyright (C) 2006-2009. kksou.com. All Rights Reserved
* License: GNU/GPL http://www.gnu.org/copyleft/gpl.html
* Website: http://www.kksou.com/php-gtk2
* 2013.4.19
*/

global $debug_mode;
# Please set this to 1 to turn on debug mode
$debug_mode = 0;

global $use_mysql_direct;
# Please set this to 1 if you are using mysql direct
$use_mysql_direct = 0;
if (!$use_mysql_direct) return;

# Please fill in the host, username, password and database name of the
# mysql database that you have used for your Joomla site
# If you forget, you can get the information from configuration.php
# locaed in your Joomla Root Folder
$mysql_host = ''; 
$mysql_user = ''; 
$mysql_password = ''; 
$mysql_database = '';
$dbprefix = 'jos_'; # the prefix used by your joomla database (in configuration.php)
$conn = mysql_connect($mysql_host, $mysql_user, $mysql_password);

if (!$conn) print "<b>Error:</b> Could not connect: ". mysql_error()."<br />";
$db_selected = mysql_select_db($mysql_database);
if (!$db_selected) print "<b>Error:</b> Could not use database: ". mysql_error()."<br />";
mysql_set_charset('utf8', $conn);

?>
