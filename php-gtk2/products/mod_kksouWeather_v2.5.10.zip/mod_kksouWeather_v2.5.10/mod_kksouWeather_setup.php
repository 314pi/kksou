<?php
/**
* mod_kksouWeather_setup.php
* Author: kksou
* Copyright (C) 2006-2009. kksou.com. All Rights Reserved
* License: GNU/GPL http://www.gnu.org/copyleft/gpl.html
* Website: http://www.kksou.com/php-gtk2
* 2012.10.24
*/

if (!defined('_JEXEC')) define( '_JEXEC', 1 );
if (!defined('JPATH_BASE')) define('JPATH_BASE', $joomla_root);
if (!defined('DS')) define( 'DS', DIRECTORY_SEPARATOR );
$display_error_setting = ini_get('display_errors');
ini_set('display_errors', 0);
global $debug_mode;

$includes = $joomla_root.DS.'includes';
$lib1 = $includes.DS."defines.php";
if ($debug_mode) print "bp201. lib1 = $lib1<br />";
require_once ($lib1);
$lib2 = $includes.DS."framework.php";
if ($debug_mode) print "bp202. lib2 = $lib2<br />";
require_once ($lib2);
$mainframe = JFactory::getApplication('site');

/*if ($joomla_ver=='1.5') {
	$library2 = JPATH_BASE.DS.'libraries'.DS.'joomla'.DS.'factory.php';
	require_once( $library2);
}*/

ini_set('display_errors', $display_error_setting);

?>
