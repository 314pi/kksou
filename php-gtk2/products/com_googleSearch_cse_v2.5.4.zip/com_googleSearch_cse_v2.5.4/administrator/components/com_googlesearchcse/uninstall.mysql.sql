DROP TABLE `#__googleSearch_cse_conf`;
