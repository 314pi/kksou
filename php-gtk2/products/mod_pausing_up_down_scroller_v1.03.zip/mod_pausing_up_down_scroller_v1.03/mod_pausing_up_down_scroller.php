<?php
/**
* Pausing up-down Scroller module
* This module allows you to display an up-down scroller that pauses
* between each message! The look of the scroller is completely styled
* using external CSS, including the dimensions. Easily create a single
* line scroller just by adjusting the scroller's height appropriately!
* Author: kksou
* Copyright (C) 2006-2008. kksou.com. All Rights Reserved
* Website: http://www.kksou.com/php-gtk2/Joomla-Gadgets/
* v1.0 December 3, 2008
* v1.72 December 4, 2011 support for Joomla 1.6 and 1.7
*/

defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

$str = $params->get( 'content', '' );

$a = new stdClass;
$a->text = $str;
global $_MAMBOTS;
$_MAMBOTS->loadBotGroup( 'content' );
$params = array();
$results = $_MAMBOTS->trigger( 'onPrepareContent', array( 1, &$a, &$params) );
echo $a->text;
?>
