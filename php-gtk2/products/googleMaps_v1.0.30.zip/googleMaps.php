<?php
/**
* googleMaps plugin
* allows you to include one or more google maps
* right inside Joomla content item or article
* Author: kksou
* Copyright (C) 2006-2008. kksou.com. All Rights Reserved
* Website: http://www.kksou.com/php-gtk2
* v1.0 April 16, 2009
*/

defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );
$_MAMBOTS->registerFunction( 'onPrepareContent', 'botgoogleMaps' );

@session_start();

$lib = dirname(__FILE__).'/googleMaps/googleMaps.lib.php';
require_once($lib);

global $joomla_ver;
require_once('googleMaps/googleMaps_joomla_ver.php');

function botgoogleMaps( $published, &$row, &$params, $page=0  ) {

	if ( !$published ) {
		return true;
	}

	$is_mod = 0;
	if (isset($params->is_mod)) $is_mod = 1;

	$plugin = new googleMaps($row, $is_mod);

	return true;
}

class googleMaps {

	function googleMaps(&$row, $is_mod=0) {

		$contents = $row->text;
		global $database, $_MAMBOTS;

		if ( !isset($_MAMBOTS->_content_mambot_params['googleMaps']) ) {
			$query = "SELECT params"
			. "\n FROM #__mambots"
			. "\n WHERE element = 'googleMaps'"
			. "\n AND folder = 'content'"
			;
			$database->setQuery( $query );
			$database->loadObject($mambot);
			$_MAMBOTS->_content_mambot_params['googleMaps'] = $mambot;
		}

		$mambot = $_MAMBOTS->_content_mambot_params['googleMaps'];
		$botParams = new mosParameters( $mambot->params );

		$param = new stdClass;
		$param->api_key = $botParams->def( 'api_key', '' );
		$param->width = $botParams->def( 'width', 640 );
		$param->height = $botParams->def( 'height', 480 );
		$param->zoom = $botParams->def( 'zoom', 15 );
		$param->template_uses_jquery = $botParams->def( 'template_uses_jquery', 0 );

		$plugin = new Plugin_googleMaps($row, $param, $is_mod);
		return true;
	}

}

?>
