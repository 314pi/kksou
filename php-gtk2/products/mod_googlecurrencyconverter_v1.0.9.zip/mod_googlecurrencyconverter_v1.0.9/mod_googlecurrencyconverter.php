<?php
/**
* GoogleCurrencyConverter module
* This module allows you to add the Google Currency Converter in a module position.
* Author: kksou
* Copyright (C) 2006-2010. kksou.com. All Rights Reserved
* License: GNU/GPL http://www.gnu.org/copyleft/gpl.html
* Website: http://www.kksou.com/php-gtk2
* v1.0 August 21, 2008
*/

defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

#display_currency_converter($params);

#function display_currency_converter($params) {
	$lib = dirname(__FILE__).'/mod_googlecurrencyconverter/mod_googlecurrencyconverter_lib.php';

	global $mosConfig_live_site;
	$lib_base = $mosConfig_live_site."/modules/mod_googlecurrencyconverter";
	$lib2 = "$lib_base/mod_googlecurrencyconverter_lib.php";
	$progress_gif = "$lib_base/mod_googlecurrencyconverter_progress.gif";
	$js_url = "$lib_base/mod_googlecurrencyconverter_ajax.js";

	require_once(dirname(__FILE__).'/mod_googlecurrencyconverter/mod_googlecurrencyconverter_helper.php');
	$mod_id = get_GoogleCurrencyConverter_mod_id();

	$currency_from = strval( $params->get( 'currency_from', 'USD') );
	$currency_to = strval( $params->get( 'currency_to', 'EUR') );
	$label_convert = strval( $params->get( 'label_convert', 'Convert') );
	$label_into = strval( $params->get( 'label_into', 'into') );
	$submit_button_label = strval( $params->get( 'submit_button_label', 'Convert') );
	$use_css = strval( $params->get( 'use_css', '0') );
	$style = strval( $params->get( 'style', '1') );
	$use_curl = intval( $params->get( 'use_curl', '1') );

	print "<script type=\"text/javascript\">
var lib_url{$mod_id}=\"$lib2\";
var progress_gif{$mod_id}=\"$progress_gif\";
var submit_button_label{$mod_id}=\"$submit_button_label\";
var label_convert{$mod_id}=\"$label_convert\";
var label_into{$mod_id}=\"$label_into\";
var style{$mod_id}=\"$style\";
var googlecurrency_use_curl{$mod_id}=\"$use_curl\";
</script>";

print "<script type=\"text/javascript\" src=\"$js_url\"></script>";

print "<div id=\"googlecurrency_container{$mod_id}\">";
require $lib;
print "</div>";

print "<script type=\"text/javascript\">googlecurrency_prepareForm('$mod_id');</script>";

#}
?>
