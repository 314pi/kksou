<?php
/**
* GoogleCurrencyConverter module
* This module allows you to add the Google Currency Converter in a module position.
* Author: kksou
* Copyright (C) 2006-2010. kksou.com. All Rights Reserved
* License: GNU/GPL http://www.gnu.org/copyleft/gpl.html
* Website: http://www.kksou.com/php-gtk2
* v1.0 August 21, 2008
*/

// no direct access

class modGoogleCurrencyConverterHelper {
	function getContent(&$params) {
	}
}

function get_GoogleCurrencyConverter_mod_id() {
	static $i=300;
	return ++$i;
}
