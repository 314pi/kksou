<?php
// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport('joomla.installer.helper');
$installer = new JInstaller();
$installer->_overwrite = true;

$pkg_path = JPATH_ADMINISTRATOR.DS.'components'.DS.'com_googledirections-toherepackage'.DS.'extensions'.DS;
$pkgs = array( 'googleMaps_v1.5.30.zip' => 'googleMaps plugin',
               'googleDirections_v1.5.20.zip'=>'googleDirections plugin',
			   'googleDirections_tohere_v1.5.15.zip'=>'googleDirections_tohere plugin'
             );

$jroot = JURI::root( true );
$comp_folder = dirname( __FILE__ );

foreach( $pkgs as $pkg => $pkgname ):
  $package = JInstallerHelper::unpack( $pkg_path.$pkg );
  if( $installer->install( $package['dir'] ) ) {
    $msgcolor = "#E0E0FF";
    $msgtext  = "$pkgname successfully installed.";
  }
  else {
    $msgcolor = "#FFD0D0"; #d0d0ff
    $msgtext  = "ERROR: Could not install the $pkgname. Please install manually.";
  }
  ?>
  <table bgcolor="<?php echo $msgcolor; ?>" width ="100%">
    <tr style="height:30px">
      <td width="50px"><img src="<?php echo $jroot;?>/administrator/images/tick.png" height="20px" width="20px"></td>
      <td><font size="2"><b><?php echo $msgtext; ?></b></font></td>
    </tr>
  </table>
<?php
JInstallerHelper::cleanupInstall( $pkg_path.$pkg, $package['dir'] );
endforeach;

$mainframe =& JFactory::getApplication();
$mainframe->set( '_messageQueue', '' );
$mainframe->enqueueMessage( sprintf( JText::_( 'The googleMaps, googleDirections and googleDirections_tohere plugins have been installed_successfully. Please make sure you enable all the 3 plugins (i.e. googleMaps, googleDirections and googleDirections_tohere) for this plugin to work' )), 'message' );

uninstallInstaller();

function uninstallInstaller( $name = 'googleDirections-ToHerePackage' ) { #googleDirections - To Here Package
	$mainframe =& JFactory::getApplication();
	$db =& JFactory::getDBO();

	$query = 'SELECT `id` FROM `#__components`'
		.' WHERE `option` = '.$db->quote( 'com_'.$name )
		.' AND `parent` = 0'
		.' LIMIT 1';
	$db->setQuery( $query );
	$id = (int) $db->loadResult();

	if ( $id > 1 ) {
		$installer =& JInstaller::getInstance();
		$installer->uninstall( 'component', $id );
	}

	$query = 'ALTER TABLE `#__components` AUTO_INCREMENT = 1';
	$db->setQuery( $query );
	$db->query();

	// Redirect with message
	$mainframe->redirect( 'index.php?option=com_installer' );
}

?>
