<?php
/**
* include_content_item plugin
* This plugin allows you to insert or include one content item
* into another content item.
* Author: kksou
* Copyright (C) 2006-2008. kksou.com. All Rights Reserved
* License: GNU/GPL http://www.gnu.org/copyleft/gpl.html
* Website: http://www.kksou.com/php-gtk2
* v1.5 May 3, 2008
* v1.5.10 Jul 8, 2011 updated jquery to the latest version jquery-1.6.4.min.js
* v1.5.11 August 17, 2011 added $allow_multiple - Allow the same article to be included multiple times within the same article

*/

defined( '_JEXEC' ) or die( 'Direct Access to this location is not allowed.' );

jimport( 'joomla.event.plugin' );
jimport( 'joomla.language.helper');

$lib = dirname(__FILE__).'/include_content_item/include_content_item.lib.php';
require_once($lib);

class plgContentinclude_content_item extends JPlugin {

	function plgContentinclude_content_item( &$subject, $params ) {
		#parent::__construct( $subject, $params );
		parent::JPlugin( $subject, $params );
 	}

	function onPrepareContent( &$row, &$params, $limitstart=0 ) {

		$plugin = new Plugin_IncludeContentItem($row);

		return true;
	}
}

?>
