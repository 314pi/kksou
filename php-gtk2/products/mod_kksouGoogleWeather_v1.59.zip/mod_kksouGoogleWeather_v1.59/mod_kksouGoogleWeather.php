<?php
/**
* GoogleWeather module
* This module allows you to add the Google Weather in a module position.
* Author: kksou
* Copyright (C) 2006-2009. kksou.com. All Rights Reserved
* License: GNU/GPL http://www.gnu.org/copyleft/gpl.html
* Website: http://www.kksou.com/php-gtk2
* v1.5 October 1, 2009
* v1.51 October 6, 2009 streamlined javascript codes
*/

// no direct access
defined('_JEXEC') or die('Restricted access');

require_once (dirname(__FILE__).DS.'helper.php');
$lib = dirname(__FILE__).DS.'mod_kksouGoogleWeather_lib.php';
$mod_id = get_googleWeather_mod_id();

$mod_path = __FILE__;
$DS2 = DS;
$str = '';
$z = $mod_path;
$i = 0;
$ok = 0;
while (1) {
	$z2 = pathinfo($z);
	$str = $z2['basename'];
	++$i;
	if ($i>10) break;
	if ($str=='modules') {
		$ok = 1;
		break;
	}
	$z = $z2['dirname'];
}
$joomla_root = $z2['dirname'];
$joomla_root = str_replace(DS, '|_%$', $joomla_root);

$mosConfig_live_site = JURI::base();
$lib_base = $mosConfig_live_site."modules/mod_kksouGoogleWeather";
$lib2 = "$lib_base/mod_kksouGoogleWeather_lib.php";
$progress_gif = "$lib_base/mod_kksouGoogleWeather_progress.gif";
$js_url = "$lib_base/mod_kksouGoogleWeather_ajax.js";
#print "<link rel=\"stylesheet\" href=\"$lib_base/mod_kksouGoogleWeather.css\" type=\"text/css\" />";

#$a = modkksouGoogleWeatherHelper::getContent($params);
$api_key = strval( $params->get( 'API_key', '') );
$use_curl = intval( $params->get( 'use_curl', '1') );
$default_location = strval( $params->get( 'default_location', 'San Francisco, CA') );
$googleweather_unit = strval( $params->get( 'unit', 'US') );
$label_city = strval( $params->get( 'label_city', 'City') );
$label_humidity = strval( $params->get( 'label_humidity', 'Humidity: ') );
$default_country = strval( $params->get( 'default_country', '') );
$size_city = intval( $params->get( 'size_city', '12') );
$hide_input = intval( $params->get( 'hide_input', '0') );
$lang = strval( $params->get( 'lang', 'en') );
$request_interval = intval( $params->get( 'request_interval', '3') );
$hide_humidity = intval( $params->get( 'hide_humidity', '0') );
$hide_wind = intval( $params->get( 'hide_wind', '0') );
$hide_forecast = intval( $params->get( 'hide_forecast', '0') );
$popup_city = strval( $params->get( 'popup_city', 'Please enter zip code (in US,UK) or city name') );
$popup_deg_F = strval( $params->get( 'popup_deg_F', 'Click here to convert to degree F') );
$popup_deg_C = strval( $params->get( 'popup_deg_C', 'Click here to convert to degree C') );
$focus_on_city = intval( $params->get( 'focus_on_city', '1') );
$refresh_time = intval( $params->get( 'refresh_time', '60') );
$admin_mode = intval( $params->get( 'admin_mode', '0') );

print "<script type=\"text/javascript\">
var headID = document.getElementsByTagName(\"head\")[0];
var cssNode = document.createElement('link');
cssNode.type = 'text/css';
cssNode.rel = 'stylesheet';
cssNode.href = '$lib_base/mod_kksouGoogleWeather.css';
cssNode.media = 'screen';
headID.appendChild(cssNode);
</script>";

print "<script type=\"text/javascript\">
//var mod_id = \"$mod_id\";
var gw_lib_url{$mod_id}=\"$lib2\";
var gw_progress_gif{$mod_id}=\"$progress_gif\";
var joomla_root{$mod_id}='$joomla_root';
var label_city{$mod_id}=\"$label_city\";
var popup_city{$mod_id}=\"$popup_city\";
var popup_deg_F{$mod_id}=\"$popup_deg_F\";
var popup_deg_C{$mod_id}=\"$popup_deg_C\";
var size_city{$mod_id}=\"$size_city\";
var hide_input{$mod_id}=\"$hide_input\";
var lang{$mod_id}=\"$lang\";
var googleweather_unit{$mod_id}=\"$googleweather_unit\";
var default_location{$mod_id}=\"$default_location\";
var googleweather_use_curl{$mod_id}=\"$use_curl\";
var request_interval{$mod_id}=\"$request_interval\";
var hide_humidity{$mod_id}=\"$hide_humidity\";
var hide_wind{$mod_id}=\"$hide_wind\";
var hide_forecast{$mod_id}=\"$hide_forecast\";
var focus_on_city{$mod_id}=\"$focus_on_city\";
var api_key{$mod_id}=\"$api_key\";
var default_country{$mod_id}=\"$default_country\";
var label_humidity{$mod_id}=\"$label_humidity\";
var refresh_time{$mod_id}=\"$refresh_time\";
var admin_mode{$mod_id}=\"$admin_mode\";
var joomla_ver{$mod_id}=\"1.5\";
</script>";

print "<script type=\"text/javascript\" src=\"$js_url\"></script>";

require(JModuleHelper::getLayoutPath('mod_kksouGoogleWeather'));
?>