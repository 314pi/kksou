<?php
$joomla_ver = '1.6';
?>