<?php
/**
* Glossy Accordion Menu module
* This module allows you to insert the Glossy Accordion Menu
* with the tags {Glossy_Accordion_Menu} ... {/Glossy_Accordion_Menu}.
* Author: kksou
* Copyright (C) 2006-2009. kksou.com. All Rights Reserved
* Website: http://www.kksou.com/php-gtk2
* v1.0 January 20, 2009
*/

defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

$str = $params->get( 'content', '' );

$a = new stdClass;
$a->text = $str;
global $_MAMBOTS;
$_MAMBOTS->loadBotGroup( 'content' );
$params = array();
$results = $_MAMBOTS->trigger( 'onPrepareContent', array( 1, &$a, &$params) );
echo $a->text;
?>
