<?php
/**
* kksouWeather module
* This module allows you to add the Google Weather in a module position.
* Author: kksou
* Copyright (C) 2006-2009. kksou.com. All Rights Reserved
* License: GNU/GPL http://www.gnu.org/copyleft/gpl.html
* Website: http://www.kksou.com/php-gtk2
* v1.5 October 1, 2009
*/

// no direct access
defined('_JEXEC') or die('Restricted access');
if (!defined('DS')) define( 'DS', '/' );

require_once (JPATH_SITE.DS.'components'.DS.'com_content'.DS.'helpers'.DS.'route.php');

class modkksouweatherHelper {
	function getContent(&$params) {
	}
}

function get_googleweather_mod_id() {
	static $i=300;
	return ++$i;
}
