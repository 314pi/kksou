<?php
/**
* mod_kksouGoogleWeather_setup.php
* Author: kksou
* Copyright (C) 2006-2009. kksou.com. All Rights Reserved
* License: GNU/GPL http://www.gnu.org/copyleft/gpl.html
* Website: http://www.kksou.com/php-gtk2
* 2012.10.24
*/

if (!defined('_JEXEC')) define( '_JEXEC', 1 );
if (!defined('JPATH_BASE')) define('JPATH_BASE', $joomla_root);
if (!defined('DS')) define( 'DS', '/' );
#define( 'DS', DIRECTORY_SEPARATOR );
$includes = $joomla_root.DS.'includes';
$lib1 = $includes.DS."defines.php";
require_once ($lib1);
$lib2 = $includes.DS."framework.php";
require_once ($lib2);
$mainframe = JFactory::getApplication('site');

/*if ($joomla_ver=='1.5') {
	$library2 = JPATH_BASE.DS.'libraries'.DS.'joomla'.DS.'factory.php';
	require_once( $library2);
}*/

#print "bp211.<pre>"; print_r($_GET); print "</pre>";
#print "bp103. setup joomla 2.5<br>";

?>
