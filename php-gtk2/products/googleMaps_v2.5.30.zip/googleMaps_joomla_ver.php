<?php
$joomla_ver = '2.5';
?>