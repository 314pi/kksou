<?php
$joomla_ver = '1.5';
?>