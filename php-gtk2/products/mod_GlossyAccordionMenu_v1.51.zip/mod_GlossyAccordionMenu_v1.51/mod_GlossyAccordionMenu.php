<?php
/**
* Glossy Accordion Menu module
* This module allows you to insert the Glossy Accordion Menu
* with the tags {Glossy_Accordion_Menu} ... {/Glossy_Accordion_Menu}.
* Author: kksou
* Copyright (C) 2006-2009. kksou.com. All Rights Reserved
* Website: http://www.kksou.com/php-gtk2
* v1.5 January 20, 2009
* v1.51 January 20, 2010 added support for PHP 5.3 "Warning: Parameter 2 to plgContentGlossyAccordionMenu::onPrepareContent() expected to be a reference, value given in joomla\event\event.php on line 67"
*/

// no direct access
defined('_JEXEC') or die('Restricted access');
require_once (dirname(__FILE__).DS.'helper.php');
$str = modGlossyAccordionMenuHelper::getContent($params);
require(JModuleHelper::getLayoutPath('mod_GlossyAccordionMenu'));
?>