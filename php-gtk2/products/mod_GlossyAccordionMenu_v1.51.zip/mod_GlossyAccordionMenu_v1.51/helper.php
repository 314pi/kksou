<?php
/**
* Glossy Accordion Menu module
* This module allows you to insert the Glossy Accordion Menu
* with the tags {Glossy_Accordion_Menu} ... {/Glossy_Accordion_Menu}.
* Author: kksou
* Copyright (C) 2006-2009. kksou.com. All Rights Reserved
* Website: http://www.kksou.com/php-gtk2
* v1.5 January 20, 2009
*/

// no direct access
defined('_JEXEC') or die('Restricted access');

require_once (JPATH_SITE.DS.'components'.DS.'com_content'.DS.'helpers'.DS.'route.php');

class modGlossyAccordionMenuHelper {
	function getContent(&$params) {
		$str = $params->get( 'content' );
		return $str;
	}
}
